# Product Vision

BotWA no es un chatbot.

Es una plataforma SaaS de asistentes inteligentes para pequeñas empresas.

Primer vertical:
- Clínicas
- Consultorios
- Centros estéticos

Objetivo:
Reducir la pérdida de clientes ocasionada por respuestas lentas en WhatsApp.
