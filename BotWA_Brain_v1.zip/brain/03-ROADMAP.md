# Roadmap

- v0.1 Core
- v0.2 Persistencia
- v0.3 WhatsApp
- v0.4 Agenda
- v0.5 IA
- v1.0 MVP Comercial
