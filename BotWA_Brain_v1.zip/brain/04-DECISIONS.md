# Decisiones Vigentes

- La arquitectura está congelada.
- Los ADR oficiales viven en architecture/02-adrs.
- El Core solo admite correcciones de bugs.
- Toda decisión arquitectónica relevante requiere evaluación del CTO.
