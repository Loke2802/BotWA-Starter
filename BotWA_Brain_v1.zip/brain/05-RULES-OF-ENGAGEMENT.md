# Rules of Engagement

Founder
↓
CTO
↓
Lead Engineer
↓
Validation
↓
Release

Reglas:
- OpenCode implementa.
- El CTO revisa y aprueba.
- El Founder define prioridades de negocio.
