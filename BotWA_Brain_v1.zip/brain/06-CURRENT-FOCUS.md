# Current Focus

Objetivo actual:
Preparar la plataforma para iniciar la Épica de Persistencia.

Pendientes:
- Docker
- GitHub
- README
- Primer Release

Siguiente:
Épica 2 - Persistencia.
